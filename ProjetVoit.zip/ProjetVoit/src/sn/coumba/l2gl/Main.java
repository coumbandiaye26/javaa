package sn.coumba.l2gl.app;

import java.util.Calendar;
import sn.coumba.l2gl.app.enums.Etat;
import sn.coumba.l2gl.app.enums.Permis;
import sn.coumba.l2gl.app.enums.Type;
import sn.coumba.l2gl.app.model.Chauffeur;
import sn.coumba.l2gl.app.model.Vehicule;
import sn.coumba.l2gl.app.fonction.Verification;
import sn.coumba.l2gl.app.fonction.Transformation;
import sn.coumba.l2gl.app.fonction.Comparaison;

public class Main {

    public static void main(String[] args) {

        Calendar d1 = Calendar.getInstance();
        d1.set(2005, Calendar.JULY, 30);
        Calendar d2 = Calendar.getInstance();
        d2.set(2004, Calendar.JUN, 7);
        Calendar d3 = Calendar.getInstance();
        d3.set(2006, Calendar.MAY, 26);

        Chauffeur c1 = new Chauffeur(1, "Hadja Arame", "Diouf", d1, Permis.B, Etat.DISPO);
        Chauffeur c2 = new Chauffeur(2, "Mohamed", "Ndiaye", d2, Permis.C, Etat.DISPO);
        Chauffeur c3 = new Chauffeur(3, "Coumba", "Ndiaye", d3, Permis.B, Etat.INDISPO);

        Vehicule v1 = new Vehicule("DK-123-AA", TypeVehicule.LEGER, "Toyota", Etat.DISPO, 2020);
        Vehicule v2 = new Vehicule("DK-456-BB", TypeVehicule.LOURD, "Mercedes", Etat.DISPO, 2015);
        Vehicule v3 = new Vehicule("DK-789-CC", TypeVehicule.LEGER, "Renault", Etat.INDISPO, 2018);
        Vehicule v4 = new Vehicule("DK-321-DD", TypeVehicule.LOURD, "Volvo", Etat.INDISPO, 2012);

        Verification<Chauffeur, Vehicule> peutConduire = (chauffeur, vehicule) -> {
            if (vehicule.getType() == TypeVehicule.LEGER) {
                return chauffeur.getPermis() == Permis.B || chauffeur.getPermis() == Permis.A;
            } else {
                return chauffeur.getPermis() == Permis.A;
            }
        };

        System.out.println("Hadja Arame peut conduire v1 ? " + peutConduire.tester(c1, v1));
        System.out.println("Hadja Arame peut conduire v2 ? " + peutConduire.tester(c1, v2));
        System.out.println("Mohamed peut conduire v2 ? " + peutConduire.tester(c2, v2));

        Verification<Chauffeur, Vehicule> sontDisponibles = (chauffeur, vehicule) ->
                chauffeur.getEtat() == Etat.DISPO && vehicule.getEtat() == Etat.DISPO;

        System.out.println("c1 et v1 disponibles ? " + sontDisponibles.tester(c1, v1));
        System.out.println("c3 et v1 disponibles ? " + sontDisponibles.tester(c3, v1));
        System.out.println("c1 et v3 disponibles ? " + sontDisponibles.tester(c1, v3));

        Transformation<Vehicule, Boolean> estAmorti = vehicule -> {
            int anneeActuelle = Calendar.getInstance().get(Calendar.YEAR);
            return (anneeActuelle - vehicule.getAnnee()) >= 5;
        };

        System.out.println("v1 est amorti ? " + estAmorti.transformer(v1));
        System.out.println("v2 est amorti ? " + estAmorti.transformer(v2));

        Transformation<Chauffeur, Boolean> retraite = chauffeur -> {
            int anneeActuelle = Calendar.getInstance().get(Calendar.YEAR);
            int anneeNaissance = chauffeur.getDateN().get(Calendar.YEAR);
            int age = anneeActuelle - anneeNaissance;
            return age >= 60;
        };

        System.out.println("Hadja Arame retraite ? " + retraite.transformer(c1));
        System.out.println("Mohamed retraite ? " + retraite.transformer(c2));

        Transformation<Chauffeur, String> chauffeurEnString = chauffeur ->
                chauffeur.getPrenom() + " " + chauffeur.getNom() + " - Permis " + chauffeur.getPermis();

        System.out.println(chauffeurEnString.transformer(c1));

        Comparaison<Chauffeur> comparerAgeChauffeur = (ch1, ch2) -> {
            int age1 = Calendar.getInstance().get(Calendar.YEAR) - ch1.getDateN().get(Calendar.YEAR);
            int age2 = Calendar.getInstance().get(Calendar.YEAR) - ch2.getDateN().get(Calendar.YEAR);
            return Integer.compare(age1, age2);
        };

        System.out.println("Comparaison âge c1 / c2 : " + comparerAgeChauffeur.comparer(c1, c2));

        Comparaison<Vehicule> comparerTypeVehicule = (veh1, veh2) ->
                veh1.getType().compareTo(veh2.getType());

        System.out.println("Comparaison type v1 / v2 : " + comparerTypeVehicule.comparer(v1, v2));

        Verification<Chauffeur, Vehicule> affectationPossible = (chauffeur, vehicule) ->
                peutConduire.tester(chauffeur, vehicule) && sontDisponibles.tester(chauffeur, vehicule);

        System.out.println("Affectation c1 -> v1 ? " + affectationPossible.tester(c1, v1));
        System.out.println("Affectation c1 -> v2 ? " + affectationPossible.tester(c1, v2));
        System.out.println("Affectation c2 -> v2 ? " + affectationPossible.tester(c2, v2));
    }
}