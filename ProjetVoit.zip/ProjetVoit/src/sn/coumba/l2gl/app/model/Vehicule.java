package sn.coumba.l2gl.app.model;

import sn.coumba.l2gl.app.enums.Type;
import sn.coumba.l2gl.app.enums.Etat;
public class Vehicule {
    private String immatriculation;
    private Type type;
    private String marque;
    private Etat etat;
    private int annee;

    public Vehicule(String immatriculation, Type type, String marque, Etat etat, int annee) {
        this.immatriculation = immatriculation;
        this.Type = type;
        this.Etat= etat;
        this.annee = annee;
    }
    public String getImmatriculation(id) {
        return immatriculation;
    }
   public String getMarque() {
        return marque;
    }
    public Etat getEtat() {
        return etat;
    }
    public int getAnnee() {
        return annee;
    }

    public void setImmatriculation(String immatriculation) {
        this.immatriculation = immatriculation;
    }
    public void setType(Type type) {
        this.type = type;
    }
    public void setMarque(String marque) {
        this.marque = marque;
    }
    public void setEtat(Etat etat) {
        this.etat = etat;
    }
    public void setAnnee(int annee) {
        this.annee = annee;
    }

    @Override
    public String toString() {
        return "Vehicule{" +
                "immatriculation='" + immatriculation + '' +
                ", type=" + type +
                ", marque='" + marque + '' +
                ", etat=" + etat +
                ", annee=" + annee +
                '}';
    }
}