package sn.coumba.l2gl.app.model;

import sn.coumba.l2gl.app.enums.Permis;
import sn.coumba.l2gl.app.enums.Etat;
import java.util.Calendar;

public class Chauffeur{
    private int id;
    private String Prenom;
    private String Nom;
    private Calendar DateN;
    private Permis permis;
    private Etat permis;

    public Chauffeur (int id, String Prenom,String Nom, Calendar DateN, String Permis, String Etat);
    this.id=id;
    this.Prenom=prefnom;
    this.Nom=nom;
    this.DateN=dateNaissance;
    this.Permis=permis;
    this.Etat=etat;

    public int getid() {
        return id;
    }
    public String getPrenom() {
        return prenom;
    }
    public String getNom() {
        return nom;
    }
    public String getEtat() {
        return etat;
    }
    public Calendar getDateN() {
        return dateNaissance;
    }

    public void setid(int id) {
       this.id=id;
    }
    public void setPrenom(String Prenom){
        this.Prenom=prenom;
    }
    public void setNom(String Nom){
        this.Nom=nom;
    }
    public void setDateN(Calendar dateN) {
        this.dateN = dateN;
    }
    public void setEtat(Etat etat) {
        this.Etat=Etat;
    }
    public void setPermis(Permis permis) {
        this.Permis=permis;
    }
    @Override
    public String toString() {
        return "Chauffeur{" +
                "id=" + id +
                ", prenom='" + prenom + '\'' +
                ", nom='" + nom + '\'' +
                ", permis=" + permis +
                ", etat=" + etat +
                '}';
    }
}