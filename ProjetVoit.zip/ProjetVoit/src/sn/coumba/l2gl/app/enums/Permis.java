package sn.coumba.l2gl.app.model;

public Enum Permis{
    A,B;
}
