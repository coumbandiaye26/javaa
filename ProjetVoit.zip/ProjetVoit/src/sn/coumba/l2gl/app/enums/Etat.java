package sn.coumba.l2gl.app.model;

public Enum Etat{
    dispo, indispo;
}
