package sn.coumba.l2gl.app.model;

public Enum Type{
    leger, lourd;
}
