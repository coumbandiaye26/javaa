package sn.coumba.l2gl.app.fonction;

@FunctionalInterface
public interface Comparaison<T> {
    int comparer(T a, T b);
}