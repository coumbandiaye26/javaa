package sn.coumba.l2gl.app.fonction;

@FunctionalInterface
public interface Transformation<T, R> {
    R transformer(T t);
}