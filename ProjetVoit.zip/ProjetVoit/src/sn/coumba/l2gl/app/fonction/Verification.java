package sn.coumba.l2gl.app.fonction;

@FunctionalInterface
public interface Verification<T, U> {
    boolean tester(T t, U u);
}